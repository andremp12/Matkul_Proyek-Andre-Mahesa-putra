import { initSnap } from 'midtrans-snap'

export default defineNuxtPlugin(() => {
    initSnap('SB-Mid-client-dsInAfAjwcC0sJ5N', 'sandbox')
})