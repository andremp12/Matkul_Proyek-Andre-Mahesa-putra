import {useDayjs} from "#dayjs";

const dayjs = useDayjs();
dayjs.locale("id");