<template>
  <div class="fixed bg-gray-100 bottom-0 w-full border-t-2 px-8 py-6 lg:flex justify-between items-center">
        <p class="mb-2 lg:mb-0">© Copyright 2020</p>

    </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>