<script setup lang="ts">

</script>

<template>
  <div>
    <UNotifications/>
    <NuxtLayout>
      <NuxtPage/>
    </NuxtLayout>
  </div>
</template>
