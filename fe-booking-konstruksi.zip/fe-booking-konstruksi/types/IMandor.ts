export interface IMandor {
    id: number|any
    name: string|any
    email: string|any
}