export interface ITimeline {
    "id":number|any,
    "konstruksi_id":number|any,
    "name":string|any,
    "description":string|any,
    "date":string|any
}