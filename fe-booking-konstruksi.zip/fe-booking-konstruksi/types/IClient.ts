export interface IClient {
    id: number|any
    name: string|any
    email: string|any
}