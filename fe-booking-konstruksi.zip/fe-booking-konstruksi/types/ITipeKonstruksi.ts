export interface ITipeKonstruksi{
    "id":number|any,
    "name":string|any
    "harga_full":number|any
    "harga_jasa":number|any
    "image":string|any
}