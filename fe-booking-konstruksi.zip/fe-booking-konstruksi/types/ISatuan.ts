export interface ISatuan{
    "id":number|any,
    "name":string|any
    "keterangan":string|any
}